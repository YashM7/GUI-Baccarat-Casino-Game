import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;

import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

public class GuiClient extends Application{


    Scene startScene,insScene,connectScene,game_scene;
    BorderPane startPane;
    Button play_button,exit_button,instruction_button,back_button,connect_button,Player1,Banker1,Tie,deal_button,draw_one,set,exit,next_round;
    Label enter_Port,enter_ip,Player,Banker,cards,value,cards1,value1,choose_bet,bet_on;
    TextField Port,IP,player_cards,banker_cards,Pvalue,Bvalue,bet_text;
    ListView<String> error_msg_text;
    int current_bet = 0;
    String user_bet_on = "";
    PauseTransition pause, pause1;

    //	Server serverConnection;
    ThreadedClient clientConnection;
    BaccaratInfo BInfo1,B2;

    ListView<String>  listItems2;


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        // TODO Auto-generated method stub
        primaryStage.setTitle("Baccarat");

        //Intro Scene
        play_button = new Button("Start Game");
        play_button.setStyle("-fx-background-color: Chartreuse;");
        play_button.setOnAction(e->primaryStage.setScene(connectScene));

        instruction_button = new Button("Instructions");
        instruction_button.setStyle("-fx-background-color: yellow;");
        instruction_button.setOnAction(e->primaryStage.setScene(insScene));

        exit_button = new Button("Exit");

        exit_button.setOnAction(e->{
            Platform.exit();
            System.exit(0);
        });

        exit_button.setStyle("-fx-background-color: red;");

        Image pic = new Image("Baccarat.jpg");
        ImageView iView = new ImageView(pic);

        iView.setFitHeight(350);
        iView.setFitWidth(500);
        iView.setPreserveRatio(true);

        // create a label
        Label label_center = new Label("");
        Label label_bottom = new Label("Welcome to the Game!");
        label_bottom.setFont(new Font("Arial", 24));
        Label label_left = new Label("");
        Label label_right = new Label("");

        // create a BorderPane
        BorderPane pane = new BorderPane(label_center,
                iView, label_right, label_bottom, label_left);

        // set alignment
        BorderPane.setAlignment(iView, Pos.CENTER);
        BorderPane.setAlignment(label_bottom, Pos.CENTER);
        BorderPane.setAlignment(label_left, Pos.CENTER);
        BorderPane.setAlignment(label_right, Pos.CENTER);
        pane.setStyle("-fx-background-color: lightblue;");

        VBox vbox = new VBox();
        HBox hbox = new HBox();
        hbox.setPadding(new Insets(15, 12, 15, 12));
        hbox.setStyle("-fx-background-color: lightpink;");
        hbox.getChildren().add(play_button);
        hbox.setAlignment(Pos.CENTER);

        HBox hbox2 = new HBox();
        hbox2.setPadding(new Insets(0, 12, 15, 12));
        hbox2.setStyle("-fx-background-color: lightpink;");
        hbox2.getChildren().add(instruction_button);
        hbox2.setAlignment(Pos.CENTER);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(0, 12, 15, 12));
        hbox1.setStyle("-fx-background-color: lightpink;");
        hbox1.getChildren().add(exit_button);
        hbox1.setAlignment(Pos.CENTER);

        vbox.getChildren().addAll(pane,hbox,hbox2,hbox1);
        startScene = new Scene(vbox,700,515);

        BInfo1 = new BaccaratInfo();


        //Instruction screen
        play_button = new Button("Start Game");
        Image pic1 = new Image("game_ins.jpg");
        ImageView iView1 = new ImageView(pic1);

        iView1.setFitHeight(450);
        iView1.setFitWidth(500);
        iView1.setPreserveRatio(true);

        Image pic2 = new Image("pdf.jpg");
        ImageView iView2 = new ImageView(pic2);

        iView2.setFitHeight(450);
        iView2.setFitWidth(500);
        iView2.setPreserveRatio(true);

        back_button = new Button("Back");
        back_button.setOnAction(e->primaryStage.setScene(startScene));

        VBox vbox1 = new VBox();
        HBox hbox3 = new HBox();
        hbox3.setSpacing(10);
        hbox3.getChildren().addAll(iView1,iView2);

        HBox hbox4 = new HBox();
        hbox4.getChildren().add(back_button);
        hbox4.setAlignment(Pos.CENTER);

        vbox1.getChildren().addAll(hbox3,hbox4);
        insScene = new Scene(vbox1,800,515);


        //Connect scene
        enter_Port = new Label("Enter Port Number: ");
        enter_Port.setTranslateX(150);
        enter_Port.setTranslateY(15);
        enter_Port.setFont(new Font("Arial", 15));

        Port = new TextField();
        Port.setTranslateX(170);
        Port.setTranslateY(10);

        enter_ip = new Label("Enter ip address: ");
        enter_ip.setTranslateX(150);
        enter_ip.setTranslateY(50);
        enter_ip.setFont(new Font("Arial", 15));

        IP = new TextField();
        IP.setTranslateX(185);
        IP.setTranslateY(45);

        connect_button = new Button("Connect");
        connect_button.setStyle("-fx-background-color: Chartreuse;");

        HBox hbox5 = new HBox();
        hbox5.getChildren().addAll(enter_Port,Port);

        HBox hbox6 = new HBox();
        hbox6.getChildren().addAll(enter_ip,IP);

        HBox hbox7 = new HBox();
        hbox7.getChildren().addAll(connect_button);
        hbox7.setTranslateX(-20);
        hbox7.setTranslateY(80);
        hbox7.setAlignment(Pos.CENTER);


        VBox vbox2 = new VBox();
        vbox2.getChildren().addAll(hbox5,hbox6,hbox7);

        connectScene = new Scene(vbox2,800,515);

        connect_button.setOnAction(e-> {
            primaryStage.setScene(game_scene);
            primaryStage.setTitle("Baccarat Game");

            BInfo1.setClientPort(Integer.parseInt(Port.getText()));
            BInfo1.setClient_address(IP.getText());

            clientConnection = new ThreadedClient(data->{
                Platform.runLater(()->{
                    B2 = new BaccaratInfo();
                    B2 = (BaccaratInfo)data;

                error_msg_text.getItems().clear();
                error_msg_text.getItems().add(B2.Message);

                });
            },Port.getText(),IP.getText());

            clientConnection.start();
        });

        //Game scene
        Image pic3 = new Image("dealer.png");
        ImageView iView3 = new ImageView(pic3);

        iView3.setFitHeight(150);
        iView3.setFitWidth(250);
        iView3.setPreserveRatio(true);

        HBox hbox8 = new HBox();
        hbox8.getChildren().add(iView3);
        hbox8.setTranslateX(380);


        Player = new Label("Player");
        Player.setTranslateX(150);
        Player.setTranslateY(15);
        Player.setFont(new Font("Arial", 18));

        cards = new Label("cards:");
        cards.setTranslateX(-200);
        cards.setTranslateY(45);
        cards.setFont(new Font("Arial", 18));

        player_cards = new TextField();
        player_cards.setTranslateX(55);
        player_cards.setTranslateY(45);
        player_cards.setPrefWidth(200);
        player_cards.setEditable(false);

        value = new Label("value:");
        value.setTranslateX(-250);
        value.setTranslateY(95);
        value.setFont(new Font("Arial", 18));

        Pvalue = new TextField();
        Pvalue.setTranslateX(-245);
        Pvalue.setTranslateY(95);
        Pvalue.setPrefWidth(200);
        Pvalue.setEditable(false);


        Banker = new Label("Banker");
        Banker.setTranslateX(650);
        Banker.setTranslateY(15);
        Banker.setFont(new Font("Arial", 18));

        cards1 = new Label("cards:");
        cards1.setTranslateX(10);
        cards1.setTranslateY(40);
        cards1.setFont(new Font("Arial", 18));

        banker_cards = new TextField();
        banker_cards.setTranslateX(20);
        banker_cards.setTranslateY(40);
        banker_cards.setPrefWidth(200);
        banker_cards.setEditable(false);

        value1 = new Label("value:");
        value1.setTranslateX(-240);
        value1.setTranslateY(95);
        value1.setFont(new Font("Arial", 18));

        Bvalue = new TextField();
        Bvalue.setTranslateX(-225);
        Bvalue.setTranslateY(90);
        Bvalue.setPrefWidth(200);
        Bvalue.setEditable(false);


        HBox hbox9 = new HBox();
        hbox9.getChildren().addAll(Player,Banker,player_cards,cards,value,Pvalue,cards1,banker_cards,value1,Bvalue);

        pause = new PauseTransition(Duration.seconds(2));
        pause.setOnFinished(e->{
            String PlayerCardsPrint = new String();
            String BankerCardsPrint = new String();

            for(int i=0;i<2;i++){

                String Value = String.valueOf(((B2.playerHand).get(i)).value);

                if(((B2.playerHand).get(i)).value==11){
                    Value = "J";
                }
                else if(((B2.playerHand).get(i)).value==12){
                    Value = "Q";
                }
                else if(((B2.playerHand).get(i)).value==13){
                    Value = "K";
                }
                PlayerCardsPrint = PlayerCardsPrint + ((B2.playerHand).get(i)).suite+" "+Value+" ";

            }
            player_cards.clear();
            player_cards.setText(PlayerCardsPrint);

            Pvalue.clear();
            Pvalue.setText(String.valueOf(B2.playerValue));


            for(int i=0;i< 2;i++){
                String Value = String.valueOf(((B2.bankerHand).get(i)).value);

                if(((B2.bankerHand).get(i)).value==11){
                    Value = "J";
                }
                else if(((B2.bankerHand).get(i)).value==12){
                    Value = "Q";
                }
                else if(((B2.bankerHand).get(i)).value==13){
                    Value = "K";
                }
                BankerCardsPrint = BankerCardsPrint+ ((B2.bankerHand).get(i)).suite+" "+Value+" ";

            }

            banker_cards.clear();
            banker_cards.setText(BankerCardsPrint);
            System.out.println(B2.Message);

            Bvalue.clear();
            Bvalue.setText(String.valueOf(B2.bankerValue));
            draw_one.setDisable(false);
            exit_button.setDisable(false);

        });

        EventHandler<ActionEvent> deal_Handler = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                exit_button.setDisable(true);
                deal_button.setDisable(true);
                Player1.setDisable(true);
                Banker1.setDisable(true);
                Tie.setDisable(true);
                set.setDisable(true);
                pause.play();

            }

        };


        EventHandler<ActionEvent> set_bet_handler = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                // TODO Auto-generated method stub
                current_bet = Integer.parseInt(bet_text.getText());
                BInfo1.setCurrent_Bet(current_bet);
                if(current_bet != 0 && user_bet_on != "") {
                    clientConnection.send(BInfo1);
                    deal_button.setDisable(false);
                    deal_button.setOnAction(deal_Handler);
                }
            }

        };


        choose_bet = new Label("Enter amount to bet $");
        bet_text = new TextField();
        set = new Button("Set bet");
        set.setOnAction(set_bet_handler);
        HBox hbox10 = new HBox();
        hbox10.getChildren().addAll(choose_bet,bet_text,set);
        hbox10.setTranslateX(360);
        hbox10.setTranslateY(120);
        choose_bet.setFont(new Font("Arial", 18));

        EventHandler<ActionEvent> user_bet_Handler = new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent e) {
                // TODO Auto-generated method stub
                Button b1 = (Button)e.getSource();
                Player1.setDisable(false);
                Banker1.setDisable(false);
                Tie.setDisable(false);
                b1.setDisable(true);
                user_bet_on = ((Button)e.getSource()).getText();
                BInfo1.setBetOn(user_bet_on);
                if(current_bet != 0 && user_bet_on != "") {
                    clientConnection.send(BInfo1);
                    deal_button.setDisable(false);
                    deal_button.setOnAction(deal_Handler);
                }
            }

        };

        bet_on = new Label("Selct whom to bet on");
        bet_on.setFont(new Font("Arial", 18));

        HBox hbox12 = new HBox();
        hbox12.getChildren().add(bet_on);
        hbox12.setTranslateX(420);
        hbox12.setTranslateY(160);

        Player1 = new Button("Player");
        Banker1 = new Button("Banker");
        Tie = new Button("Tie");

        Player1.setOnAction(user_bet_Handler);
        Banker1.setOnAction(user_bet_Handler);
        Tie.setOnAction(user_bet_Handler);

        HBox hbox13 = new HBox();
        hbox13.getChildren().addAll(Player1,Banker1,Tie);
        hbox13.setSpacing(10);
        hbox13.setTranslateX(430);
        hbox13.setTranslateY(170);


        deal_button = new Button("Deal Hands");
        deal_button.setDisable(true);

        draw_one = new Button("Draw card");
        draw_one.setDisable(true);

        pause1 = new PauseTransition(Duration.seconds(2));

        pause1.setOnFinished(e->{
            String PlayerCardsPrint = new String();
            String BankerCardsPrint = new String();

            for(int i=0;i<B2.playerHand.size();i++){

                String Value = String.valueOf(((B2.playerHand).get(i)).value);

                if(((B2.playerHand).get(i)).value==11){
                    Value = "J";
                }
                else if(((B2.playerHand).get(i)).value==12){
                    Value = "Q";
                }
                else if(((B2.playerHand).get(i)).value==13){
                    Value = "K";
                }
                PlayerCardsPrint = PlayerCardsPrint + ((B2.playerHand).get(i)).suite+" "+Value+" ";

                next_round.setDisable(false);

            }

            player_cards.clear();
            player_cards.setText(PlayerCardsPrint);

            Pvalue.clear();
            Pvalue.setText(String.valueOf(B2.playerValue1));


            for(int i=0;i< B2.bankerHand.size();i++){
                String Value = String.valueOf(((B2.bankerHand).get(i)).value);

                if(((B2.bankerHand).get(i)).value==11){
                    Value = "J";
                }
                else if(((B2.bankerHand).get(i)).value==12){
                    Value = "Q";
                }
                else if(((B2.bankerHand).get(i)).value==13){
                    Value = "K";
                }
                BankerCardsPrint = BankerCardsPrint+ ((B2.bankerHand).get(i)).suite+" "+Value+" ";

            }

            banker_cards.clear();
            banker_cards.setText(BankerCardsPrint);

            Bvalue.clear();
            Bvalue.setText(String.valueOf(B2.bankerValue1));

            error_msg_text.getItems().clear();
            error_msg_text.getItems().add(("You bet on "+B2.bet_on));
            error_msg_text.getItems().add(" Result is :"+B2.result);
            error_msg_text.getItems().add("Total Winning is "+B2.total_winning+"!");
            exit.setDisable(false);

        });

        draw_one.setOnAction(e->{
            draw_one.setDisable(true);
            exit.setDisable(true);
            pause1.play();

        });

        exit = new Button("Exit");
        next_round = new Button("Next Round");
        next_round.setDisable(true);

        next_round.setOnAction(e->{
            double totalWinning = B2.total_winning;
            String SocketAddress =B2.getClient_address();
            int portNo = B2.getClientPort();

            BInfo1 = new BaccaratInfo();
            B2 = new BaccaratInfo();

            BInfo1.total_winning = totalWinning;

            BInfo1.setClient_address(SocketAddress);
            BInfo1.setClientPort(portNo);

            user_bet_on="";
            current_bet=0;

            Player1.setDisable(false);

            Banker1.setDisable(false);
            Tie.setDisable(false);

            next_round.setDisable(true);
            set.setDisable(false);

            bet_text.clear();
            error_msg_text.getItems().clear();

            player_cards.clear();
            banker_cards.clear();

            Pvalue.clear();
            Bvalue.clear();

        });

        exit.setOnAction(e->{
            Platform.exit();
            System.exit(0);
        });

        HBox hbox14 = new HBox();
        hbox14.getChildren().addAll(deal_button,draw_one,next_round,exit);
        hbox14.setTranslateX(360);
        hbox14.setTranslateY(190);
        hbox14.setSpacing(10);


        error_msg_text = new ListView<String>();
        error_msg_text.setMaxSize(1000,75);
        HBox hbox15 = new HBox();
        hbox15.getChildren().addAll(error_msg_text);
        hbox15.setTranslateX(400);
        hbox15.setTranslateY(220);




        VBox vbox3 = new VBox();
        vbox3.getChildren().addAll(hbox8,hbox9,hbox10,hbox12,hbox13,hbox14,hbox15);
        vbox3.setStyle("-fx-background-color: white;");

        game_scene = new Scene(vbox3,1120,600);

        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });

        primaryStage.setScene(startScene);
        primaryStage.show();

    }

}
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;



public class ThreadedClient extends Thread{


	Socket socketClient;

	ObjectOutputStream out;
	ObjectInputStream in;
	int port_no = 5555;
	String ip_address = "127.0.0.1";

	private Consumer<Serializable> callback;

	ThreadedClient(Consumer<Serializable> call,String portString,String ipAddress){

		int portNo = Integer.parseInt(portString);

		port_no = portNo;

		ip_address =  ipAddress;

		callback = call;
	}

	public void run() {

		try {
			socketClient= new Socket(ip_address,port_no);
			out = new ObjectOutputStream(socketClient.getOutputStream());
			in = new ObjectInputStream(socketClient.getInputStream());
			socketClient.setTcpNoDelay(true);
		}
		catch(Exception e) {
			System.out.println("Message did not go");
		}

		while(true) {

			try {
				BaccaratInfo message = new BaccaratInfo();
				message = (BaccaratInfo)in.readObject();
				callback.accept(message);
			} catch(Exception e) {
				System.out.println("Server got closed unexpectedly.");
				break;
			}
		}

	}

	public void send(BaccaratInfo data) {

		try {
			out.writeObject(data);
		} catch (IOException e) {
			System.out.println("Message did not go");
		}
	}


}

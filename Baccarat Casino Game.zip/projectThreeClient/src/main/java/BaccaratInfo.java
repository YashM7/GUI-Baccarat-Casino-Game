import java.io.Serializable;
import java.util.ArrayList;

public class BaccaratInfo implements Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	String bet_on;
	String client_address;

	ArrayList<Card> playerHand;
	ArrayList<Card> bankerHand;

	double current_bet;
	double total_winning;
	int client_port;
	String Message;
	int playerValue;
	int playerValue1;

	int bankerValue;
	int bankerValue1;
	String result;

	BaccaratInfo(){
		Message= new String();
		client_port = 0;
		playerHand= new ArrayList<>();
		bankerHand = new ArrayList<>();
		playerValue = 0;
		playerValue1 = 0;
		bankerValue = 0;
		bankerValue1 = 0;
		total_winning=0;
	}

	String getClient_address(){
		return client_address;
	}

	void setClient_address(String address){
		client_address=address;
	}

	int getClientPort(){
		return client_port;
	}

	void setClientPort(int clientPort){
		client_port = clientPort;
	}
	double getCurrent_Bet(){
		return current_bet;
	}

	void setCurrent_Bet(double bet){
		current_bet = bet;
	}
	double getTotalWinning(){
		return total_winning;
	}

	void setTotalWinning(double winning){
		total_winning = total_winning+ winning;
	}

	String getBetOn(){
		return bet_on;
	}

	void setBetOn(String BetsOn){
		bet_on=BetsOn;
	}

	ArrayList<Card> getPlayerHand(){
		return playerHand;
	}

	void setPlayerHand(ArrayList<Card> PlayerHand){
		playerHand = PlayerHand;
	}

	ArrayList<Card> getBankerHand(){
		return bankerHand;
	}

	void setBankerHand(ArrayList<Card> BankerHand){
		bankerHand = BankerHand;
	}


}

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class BaccaratDealer {

	String[] Type = {"Hearts", "Clubs", "Diamonds", "Spades"};
	String[] Value = {"1", "13", "12", "11", "10", "9", "8", "7", "6", "5", "4", "3", "2"};

	ArrayList<Card> deck = new ArrayList<>();
	int Deck_counter = 0;
	int pos = 0;

	Set<Integer> usedCard = new HashSet<Integer>();

	public void generateDeck() {
		Deck_counter = 52;

		for(int i = 0 ; i < Type.length ; i++) {
			for(int j = 0 ; j < Value.length ; j++) {

				int val = 0;
				val = Integer.parseInt(Value[j]);
				deck.add(new Card(Type[i],val));
			}
		}

	}
	public ArrayList<Card> dealHand() {

		ArrayList<Card> Draw_two = new ArrayList<>();


		Draw_two.add(deck.get(pos));
		usedCard.add(pos);
		pos++;
		Draw_two.add(deck.get(pos));
		usedCard.add(pos);
		pos++;

		Deck_counter = Deck_counter - 2;
		return Draw_two;
	}

	public Card drawOne() {

		pos++;
		Deck_counter--;
		return deck.get(pos-1);
	}

	public void shuffleDeck() {

		deck.clear();
		generateDeck();
		usedCard.clear();

		Random rand = new Random();

		for(int i=0;i < Deck_counter; i++){
			int r= rand.nextInt(52);

			Card temp = deck.get(r);

			deck.set(r,deck.get(i));
			deck.set(i,temp);
		}
	}

	public int deckSize() {

		return Deck_counter;
	}
}
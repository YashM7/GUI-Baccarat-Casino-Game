import java.util.ArrayList;

public class BaccaratGame {

	ArrayList<Card> playerHand;
	ArrayList<Card> bankerHand;
	BaccaratDealer theDealer;
	String bet_on;
	double currentBet;
	double totalWinnings;
	String result;

	int playerValue;
	int playerValue1;

	int BankerValue;
	int BankerValue1;

	BaccaratGame(){

		theDealer = new BaccaratDealer();
		playerHand = new ArrayList<>();
		bankerHand = new ArrayList<>();
		currentBet = 0;
		totalWinnings = 0;
		theDealer.shuffleDeck();
		playerHand = theDealer.dealHand();
		bankerHand = theDealer.dealHand();
		Card temp,temp1;
		playerValue =  BaccaratGameLogic.handTotal(playerHand);
		BankerValue = BaccaratGameLogic.handTotal(bankerHand );

		if((playerValue!=8)||(playerValue!=9)||(BankerValue!=8)||(BankerValue!=9)) {

			if (BaccaratGameLogic.evaluatePlayerDraw(playerHand)) {
				temp = new Card((theDealer.drawOne()).getCardSuite(), (theDealer.drawOne()).getCardValue());
				playerHand.add(temp);
			} else {
				temp = new Card("Joker", 0);
			}


			if (BaccaratGameLogic.evaluateBankerDraw(bankerHand, temp)) {
				temp1 = new Card((theDealer.drawOne()).getCardSuite(), (theDealer.drawOne()).getCardValue());
				bankerHand.add(temp1);

			}

			playerValue1 = BaccaratGameLogic.handTotal(playerHand);
			BankerValue1 = BaccaratGameLogic.handTotal(bankerHand);
		}
		else{
			playerValue1 = playerValue;
			BankerValue1 = BankerValue;

		}
	}

	public double evaluateWinnings() {

		result = BaccaratGameLogic.whoWon(playerHand,bankerHand);

		if(bet_on.equals("Player") && result.equals("Player wins")) {
			totalWinnings = totalWinnings + currentBet;
			return totalWinnings;
		}

		if(bet_on.equals("Banker") && result.equals("Banker wins")) {
			totalWinnings = totalWinnings + (currentBet*0.95);
			return totalWinnings;
		}

		if(bet_on.equals("Tie") && result.equals("Tie")) {
			totalWinnings = totalWinnings + (currentBet*8);
			return totalWinnings;
		}

		if((bet_on.equals("Player") && result.equals("Banker wins"))||
				(bet_on.equals("Banker") && result.equals("Player wins"))||
				(bet_on.equals("Tie") && result.equals("Banker wins"))||
				(bet_on.equals("Tie") && result.equals("Player wins"))) {
			totalWinnings = totalWinnings - currentBet;
			return totalWinnings;
		}

		if((bet_on.equals("Player") && result.equals("Tie")) ||
				(bet_on.equals("Banker") && result.equals("Tie")) ){
			return totalWinnings;
		}

		return 0;

	}

}
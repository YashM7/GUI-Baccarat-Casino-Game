import java.util.ArrayList;

public class BaccaratGameLogic {

	public static String whoWon(ArrayList<Card> hand1, ArrayList<Card>
			hand2) {

		String result;

		if(handTotal(hand1) == handTotal(hand2)) {
			return "Tie";
		}

		if(handTotal(hand1) > handTotal(hand2)) {
			return "Player wins";
		}
		else {
			return "Banker wins";
		}

	}
	public static int handTotal(ArrayList<Card> hand) {

		int total = 0;
		int value = 0;

		for(int i = 0 ; i < hand.size() ; i++) {

			if(hand.get(i).value > 9) {
				value = 0;
			}
			else {
				value = hand.get(i).value;
			}

			total = total + value;
			if(total > 9) {
				total = total % 10;
			}
		}
		return total;

	}

	public static boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) {
		int HandTotal = handTotal(hand);

		if(HandTotal <= 2){
			return true;
		}
		if(3 == HandTotal){
			if(playerCard.getCardValue() != 8){
				return true;
			}
			if(playerCard.getCardSuite() == "Joker"){
				return true;
			}

		}

		if(4 == HandTotal){
			if((playerCard.getCardValue() != 8)&&(playerCard.getCardValue() != 9)&&(playerCard.getCardValue() != 0)&&(playerCard.getCardValue() != 1)){
				return true;
			}
			if(playerCard.getCardSuite() == "Joker"){
				return true;
			}

		}
		if(5 == HandTotal){
			if((playerCard.getCardValue() == 4)||(playerCard.getCardValue() == 5)||(playerCard.getCardValue() == 6)||(playerCard.getCardValue() == 7)){
				return true;
			}
			if(playerCard.getCardSuite() == "Joker"){
				return true;
			}

		}
		if(6 == HandTotal){
			if((playerCard.getCardValue() == 7)||(playerCard.getCardValue() == 6)){
				return true;
			}

		}

		return false;

	}

	public static boolean evaluatePlayerDraw(ArrayList<Card> hand) {
		int HandTotal = handTotal(hand);

		if(HandTotal <= 5) {
			return true;
		}
		return false;
	}
}

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;

import javafx.application.Platform;
import javafx.scene.control.ListView;


public class ThreadedServer{

	int count = 1;
	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();
	TheServer server;
	private Consumer<Serializable> callback;
	int Port_no=555;


	ThreadedServer(Consumer<Serializable> call,String portNo){

		Port_no = Integer.parseInt(portNo);


		callback = call;
		server = new TheServer();
		server.start();
	}


	public class TheServer extends Thread{

		public void run() {

			try(ServerSocket mysocket = new ServerSocket(Port_no);){
				System.out.println("Server is waiting for a client!");


				while(true) {


					ClientThread c = new ClientThread(mysocket.accept(), count);
					clients.add(c);
					callback.accept("client has connected to server: " + "client #" + count);
					callback.accept("Total no of client are "+clients.size()+".");
					c.start();

					count++;

				}
			}//end of try
			catch(Exception e) {
				callback.accept("Server socket did not launch");
			}
		}//end of while
	}

	public void updateClients(String warning) { // updates client if we turn of client
		for(int i = 0; i < clients.size(); i++) {
			ClientThread t = clients.get(i);
			try {
				t.message.Message = warning;
				BaccaratInfo data = new BaccaratInfo();

				data.setClient_address(t.message.getClient_address());
				data.setClientPort(t.message.getClientPort());

				data.setCurrent_Bet(t.message.getCurrent_Bet());
				data.setTotalWinning(t.message.getTotalWinning());


				data.setBankerHand(t.message.getBankerHand());
				data.setBetOn(t.message.getBetOn());

				data.result = t.message.result;
				data.Message = warning;

				data.playerValue=t.message.playerValue;
				data.playerValue1=t.message.playerValue1;

				data.bankerValue=t.message.bankerValue;
				data.bankerValue1=t.message.bankerValue1;

				t.out.writeObject(data);
			}
			catch(Exception e) {
				System.out.println("Message did not go");
			}
		}
		count=1;
	}


	class ClientThread extends Thread{


		Socket connection;
		int count;
		ObjectInputStream in;
		ObjectOutputStream out;
		BaccaratInfo message;

		ClientThread(Socket s, int count){
			this.connection = s;
			this.count = count;
			message = new BaccaratInfo();
		}

		public void run(){

			try {
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);
			}
			catch(Exception e) {
				System.out.println("Streams not open");
			}

			while(true) {
				try { // takes in the input
					message = (BaccaratInfo)in.readObject();
					callback.accept("client: "+count+" bet on " +message.getBetOn()+" "+message.getCurrent_Bet()+" $.");

					BaccaratGame d1= new BaccaratGame(); // call appropriate game function

					d1.bet_on = message.getBetOn();
					d1.currentBet = message.getCurrent_Bet();

					message.setPlayerHand(d1.playerHand);
					message.setBankerHand(d1.bankerHand);

					message.playerValue = d1.playerValue;
					message.playerValue1 = d1.playerValue1;

					message.bankerValue = d1.BankerValue;
					message.bankerValue1 = d1.BankerValue1;

					d1.evaluateWinnings();

					message.result = d1.result;

					message.setTotalWinning(d1.totalWinnings);
					callback.accept(message.result+" the game");
					callback.accept("client: "+count+" won : "+message.getTotalWinning()+" $.");


					try { // // send back to client
						out.writeObject(message);
					}
					catch(Exception e) {
						e.printStackTrace();
						System.out.println("Message didn't go out properly");
					}


				}
				catch(Exception e) {
					callback.accept("OOOOPPs...Something wrong with the socket from client: " + count + "....closing down!");

					clients.remove(this);
					callback.accept("Total no of client left are "+clients.size()+".");
					break;
				}
			}
		}

	}
}







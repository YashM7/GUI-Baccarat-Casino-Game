import java.util.HashMap;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class GuiServer extends Application {


    Button ConnectServer,b1;
    Scene connectScene;
    Label enter_Port,s1;
    TextField  Port;
    ThreadedServer serverConnection;

    ListView<String> listItems;


    public static void main(String[] args) {
        // TODO Auto-generated method stub
        launch(args);
    }
    public void start(Stage primaryStage) throws Exception {

        listItems = new ListView<String>();
        enter_Port = new Label("Enter Port No: ");
        enter_Port.setTranslateX(150);
        enter_Port.setTranslateY(50);
        enter_Port.setFont(new Font("Arial", 15));

        Port = new TextField();
        Port.setTranslateX(185);
        Port.setTranslateY(45);

        s1 = new Label("Baccarat Game Server");
        s1.setTextAlignment(TextAlignment.CENTER);
        s1.setFont(new Font("Arial", 15));

        ConnectServer = new Button("Connect");


        ConnectServer.setOnAction(e-> { // print all information at server screen 
            primaryStage.setScene(createServerGui());
                serverConnection = new ThreadedServer(data -> {
                    Platform.runLater(() -> {
                        listItems.getItems().add(data.toString());
                    });
                },Port.getText());
        });

        HBox hbox1 = new HBox();
        hbox1.getChildren().addAll(enter_Port,Port);

        HBox hbox2 = new HBox();
        hbox2.getChildren().addAll( ConnectServer);
        hbox2.setTranslateX(-20);
        hbox2.setTranslateY(80);
        hbox2.setAlignment(Pos.CENTER);

        Scene ServerScene = createServerGui();

        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });

        b1 = new Button("Turn of Server");
        b1.setOnAction(e->{
            serverConnection.updateClients("Server got closed unexpectedly.Please close the game.");
            listItems.getItems().clear();
            Platform.exit();
            System.exit(0);
        });

        VBox vbox2 = new VBox();
        vbox2.getChildren().addAll(hbox1,hbox2);
        vbox2.setStyle("-fx-background-color: lightblue");

        connectScene = new Scene(vbox2,800,515);
        primaryStage.setScene(connectScene);
        primaryStage.setTitle("Baccarat Game Server");
        primaryStage.show();
    }

    public Scene createServerGui() {

		BorderPane pane = new BorderPane();
		pane.setPadding(new Insets(70));
		pane.setStyle("-fx-background-color: coral");
		pane.setTop(s1);
		pane.setAlignment(s1,Pos.TOP_CENTER);



		pane.setCenter(listItems);
		pane.setBottom(b1);

		return new Scene(pane, 500, 400);


	}
}
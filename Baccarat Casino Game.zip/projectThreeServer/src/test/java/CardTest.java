import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class CardTest{

    @Test
    void cardConstructorTest(){
        Card card1 = new Card("Heart", 13);
        assertEquals("Heart",card1.getCardSuite(),"Card Constructor is not working");
        assertEquals(13,card1.getCardValue(),"Card Constructor is not working");

    }
    @Test
    void cardConstructorTest1(){
        Card card1 = new Card("Spades", 7);
        assertEquals("Spades",card1.getCardSuite(),"Card Constructor is not working");
        assertEquals(7,card1.getCardValue(),"Card Constructor is not working");

    }

    @Test
    void getCardSuiteTest(){
        Card card1 = new Card("Heart", 13);
        assertEquals("Heart",card1.getCardSuite(),"Card Constructor is not working");

    }

    @Test
    void getCardSuiteTest1(){
        Card card2 = new Card("Spade", 1);
        assertEquals("Spade",card2.getCardSuite(),"Card Constructor is not working");
    }

    @Test
    void getCardValueTest(){
        Card card1 = new Card("Heart", 13);
        assertEquals(13,card1.getCardValue(),"Card Constructor is not working");

    }

    @Test
    void getCardValueTest1(){
        Card card2 = new Card("Spade", 1);
        assertEquals(1,card2.getCardValue(),"Card Constructor is not working");
    }

}
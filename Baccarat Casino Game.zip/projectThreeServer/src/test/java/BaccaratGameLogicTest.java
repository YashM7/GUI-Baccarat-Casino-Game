import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class BaccaratGameLogicTest {

    @Test
    void handTotal_test() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();
        test.drawOne();

        assertEquals(0,BaccaratGameLogic.handTotal(test.dealHand()),"Incorrect hand total");

    }

    @Test
    void handTotal_test1() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();
        test.dealHand();
        test.dealHand();
        test.dealHand();
        test.drawOne();
        assertEquals(3,BaccaratGameLogic.handTotal(test.dealHand()),"Incorrect hand total");

    }

    @Test
    void whoWon_test() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();

        ArrayList<Card> player_hand = new ArrayList<>();
        ArrayList<Card> banker_hand = new ArrayList<>();
        player_hand.add(new Card("Clubs",7));
        player_hand.add(new Card("Hearts",2));
        banker_hand.add(new Card("Clubs",4));
        banker_hand.add(new Card("Hearts",2));

        assertEquals("Player wins", BaccaratGameLogic.whoWon(player_hand, banker_hand),"Incorrect result");
    }

    @Test
    void whoWon_test1() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();

        ArrayList<Card> player_hand = new ArrayList<>();
        ArrayList<Card> banker_hand = new ArrayList<>();
        player_hand.add(new Card("Clubs",7));
        player_hand.add(new Card("Hearts",1));
        banker_hand.add(new Card("Clubs",4));
        banker_hand.add(new Card("Hearts",12));

        assertEquals("Player wins", BaccaratGameLogic.whoWon(player_hand, banker_hand),"Incorrect result");
    }

    @Test
    void whoWon_test2() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();

        ArrayList<Card> player_hand = new ArrayList<>();
        ArrayList<Card> banker_hand = new ArrayList<>();
        player_hand.add(new Card("Clubs",4));
        player_hand.add(new Card("Hearts",2));
        banker_hand.add(new Card("Clubs",7));
        banker_hand.add(new Card("Hearts",2));

        assertEquals("Banker wins", BaccaratGameLogic.whoWon(player_hand, banker_hand),"Incorrect result");
    }

    @Test
    void whoWon_test3() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();

        ArrayList<Card> player_hand = new ArrayList<>();
        ArrayList<Card> banker_hand = new ArrayList<>();
        player_hand.add(new Card("Clubs",1));
        player_hand.add(new Card("Hearts",12));
        banker_hand.add(new Card("Clubs",4));
        banker_hand.add(new Card("Hearts",4));

        assertEquals("Banker wins", BaccaratGameLogic.whoWon(player_hand, banker_hand),"Incorrect result");
    }

    @Test
    void whoWon_test4() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();

        ArrayList<Card> player_hand = new ArrayList<>();
        ArrayList<Card> banker_hand = new ArrayList<>();
        player_hand.add(new Card("Clubs",8));
        player_hand.add(new Card("Hearts",12));
        player_hand.add(new Card("Clubs",12));
        banker_hand.add(new Card("Clubs",4));
        banker_hand.add(new Card("Hearts",4));
        banker_hand.add(new Card("Hearts",10));

        assertEquals("Tie", BaccaratGameLogic.whoWon(player_hand, banker_hand),"Incorrect result");
    }

    @Test
    void whoWon_test5() {
        BaccaratDealer test = new BaccaratDealer();
        BaccaratGameLogic test1 = new BaccaratGameLogic();
        test.generateDeck();

        ArrayList<Card> player_hand = new ArrayList<>();
        ArrayList<Card> banker_hand = new ArrayList<>();
        player_hand.add(new Card("Clubs",5));
        player_hand.add(new Card("Hearts",12));
        player_hand.add(new Card("Clubs",1));
        banker_hand.add(new Card("Clubs",6));
        banker_hand.add(new Card("Hearts",10));
        banker_hand.add(new Card("Clubs",11));

        assertEquals("Tie", BaccaratGameLogic.whoWon(player_hand, banker_hand),"Incorrect result");
    }

    @Test
    void evaluatePlayerDrawTest(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand=new ArrayList<>();

        hand.add(new Card("Clubs",5));
        hand.add(new Card("Clubs",1));
        hand.add(new Card("Clubs",6));

        assertEquals(true,logic.evaluatePlayerDraw(hand),"evaluatePlayerDraw is not working");

    }

    @Test
    void evaluatePlayerDrawTest1(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand=new ArrayList<>();

        ArrayList<Card> hand1=new ArrayList<>();
        hand.add(new Card("Clubs",6));
        hand.add(new Card("Clubs",6));
        hand.add(new Card("Clubs",4));

        assertEquals(false,logic.evaluatePlayerDraw(hand),"evaluatePlayerDraw is not working");

        hand1.add(new Card("Clubs",6));
        hand1.add(new Card("Clubs",6));
        hand1.add(new Card("Clubs",1));

        assertEquals(true,logic.evaluatePlayerDraw(hand1),"evaluatePlayerDraw is not working");

    }

    @Test
    void evaluateBankerDraw(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",4);

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",1));

        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw1(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",4);
        Card playerCard1 = new Card("Joker",5);// joker means that player didn't drew a card

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",3));

        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard1),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw2(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",4);
        Card playerCard1 = new Card("Spade",7);

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",8));

        assertEquals(false,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(false,logic.evaluateBankerDraw(hand,playerCard1),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw3(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",8);

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",3));

        assertEquals(false,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw4(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",7);
        Card playerCard1 = new Card("Joker",1); // joker means that player didn't drew a card

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",4));

        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard1),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw5(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",9);
        Card playerCard1 = new Card("Spade",1);

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",4));

        assertEquals(false,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(false,logic.evaluateBankerDraw(hand,playerCard1),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw6(){
        BaccaratGameLogic logic= new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts",6);
        Card playerCard1 = new Card("Spade",4);
        Card playerCard2 = new Card("Joker",0);  // joker means that player didn't drew a card

        hand.add(new Card("Hearts",12));
        hand.add(new Card("Clubs",5));

        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard),"evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard1),"evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(true,logic.evaluateBankerDraw(hand,playerCard2),"evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw7() {
        BaccaratGameLogic logic = new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts", 9);
        Card playerCard1 = new Card("Spade", 0);

        hand.add(new Card("Hearts", 12));;
        hand.add(new Card("Clubs", 5));

        assertEquals(false, logic.evaluateBankerDraw(hand, playerCard), "evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(false, logic.evaluateBankerDraw(hand, playerCard1), "evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw8() {
        BaccaratGameLogic logic = new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts", 6);
        Card playerCard1 = new Card("Spade", 7);

        hand.add(new Card("Hearts", 12));
        hand.add(new Card("Clubs", 6));

        assertEquals(true, logic.evaluateBankerDraw(hand, playerCard), "evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(true, logic.evaluateBankerDraw(hand, playerCard1), "evaluateBankerDraw doesn't taker of all the cases");
    }

    @Test
    void evaluateBankerDraw9() {
        BaccaratGameLogic logic = new BaccaratGameLogic();
        ArrayList<Card> hand = new ArrayList<>();
        Card playerCard = new Card("Hearts", 1);
        Card playerCard1 = new Card("Spade", 2);
        Card playerCard2 = new Card("Joker", 2);

        hand.add(new Card("Hearts", 10));
        hand.add(new Card("Clubs", 6));

        assertEquals(false, logic.evaluateBankerDraw(hand, playerCard), "evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(false, logic.evaluateBankerDraw(hand, playerCard1), "evaluateBankerDraw doesn't taker of all the cases");
        assertEquals(false, logic.evaluateBankerDraw(hand, playerCard2), "evaluateBankerDraw doesn't taker of all the cases");
    }

}
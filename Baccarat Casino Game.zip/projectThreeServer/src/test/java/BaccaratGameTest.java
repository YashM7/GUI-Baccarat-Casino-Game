import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class BaccaratGameTest {

    @Test
    void evaluateWinnings_test() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Player";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",2));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));

        assertEquals(100,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test1() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Player";
        game.currentBet = 50;

        game.playerHand.add(new Card("Spades",4));
        game.playerHand.add(new Card("Spades",12));
        game.playerHand.add(new Card("Hearts",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Clubs",2));

        assertEquals(50,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test2() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Player";
        game.currentBet = 50;

        game.playerHand.add(new Card("Spades",4));
        game.playerHand.add(new Card("Spades",12));
        game.playerHand.add(new Card("Hearts",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Clubs",2));

        assertEquals(50,game.evaluateWinnings(),"Incorrect total winnings");

        game.playerHand.clear();
        game.bankerHand.clear();

        game.bet_on = "Player";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",2));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));

        assertEquals(150,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test3() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Banker";
        game.currentBet = 100;

        game.bankerHand.add(new Card("Spades",7));
        game.bankerHand.add(new Card("Spades",2));
        game.playerHand.add(new Card("Hearts",7));
        game.playerHand.add(new Card("Spades",1));

        assertEquals(95,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test4() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Banker";
        game.currentBet = 50;

        game.playerHand.add(new Card("Spades",4));
        game.playerHand.add(new Card("Spades",12));
        game.playerHand.add(new Card("Hearts",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(47.5,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test5() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Banker";
        game.currentBet = 50;

        game.playerHand.add(new Card("Spades",4));
        game.playerHand.add(new Card("Spades",12));
        game.playerHand.add(new Card("Hearts",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(47.5,game.evaluateWinnings(),"Incorrect total winnings");

        game.playerHand.clear();
        game.bankerHand.clear();

        game.bet_on = "Banker";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",2));

        assertEquals(142.5,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test6() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Banker";
        game.currentBet = 50;

        game.playerHand.add(new Card("Spades",4));
        game.playerHand.add(new Card("Spades",12));
        game.playerHand.add(new Card("Hearts",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(47.5,game.evaluateWinnings(),"Incorrect total winnings");

        game.playerHand.clear();
        game.bankerHand.clear();

        game.bet_on = "Player";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Spades",2));

        assertEquals(-52.5,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test7() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Tie";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(800,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test8() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Player";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(game.totalWinnings,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test9() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Player";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",2));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(100,game.evaluateWinnings(),"Incorrect total winnings");

        game.playerHand.clear();
        game.bankerHand.clear();

        game.bet_on = "Banker";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",1));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(game.totalWinnings,game.evaluateWinnings(),"Incorrect total winnings");

    }

    @Test
    void evaluateWinnings_test10() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Banker";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",2));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(-100,game.evaluateWinnings(),"Incorrect total winnings");
    }

    @Test
    void evaluateWinnings_test11() {
        BaccaratGame game = new BaccaratGame();
        game.playerHand = new ArrayList<>();
        game.bankerHand = new ArrayList<>();

        game.bet_on = "Tie";
        game.currentBet = 100;

        game.playerHand.add(new Card("Spades",7));
        game.playerHand.add(new Card("Spades",2));
        game.bankerHand.add(new Card("Hearts",7));
        game.bankerHand.add(new Card("Clubs",1));

        assertEquals(-100,game.evaluateWinnings(),"Incorrect total winnings");
    }

}
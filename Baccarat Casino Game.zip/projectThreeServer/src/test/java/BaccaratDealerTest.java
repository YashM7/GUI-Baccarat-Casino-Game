import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class BaccaratDealerTest {

	@Test
	void GenerateDeck_Test() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();

		assertEquals(52,test.deckSize(),"Deck does not contain 52 cards");

	}

	@Test
	void GenerateDeck1_Test() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();

		assertEquals(1,test.deck.get(0).value,"Different Values");
		assertEquals("Hearts",test.deck.get(0).suite,"Different Suits");

	}

	@Test
	void dealHand_Test() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();
		test.dealHand();
		assertEquals(50,test.deckSize(),"Deal hand failed");

	}

	@Test
	void dealHand_Test1() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();
		test.dealHand();
		assertEquals(50,test.deckSize(),"Deal hand failed");

		test.dealHand();
		test.dealHand();
		assertEquals(46,test.deckSize(),"Deal hand failed");

	}

	@Test
	void drawOne_Test() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();
		test.drawOne();
		assertEquals(51,test.deckSize(),"Draw one failed");

	}

	@Test
	void drawOne_Test1() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();
		test.drawOne();
		assertEquals(51,test.deckSize(),"Draw one failed");

		test.drawOne();
		test.drawOne();
		test.drawOne();
		assertEquals(48,test.deckSize(),"Draw one failed");

	}

	@Test
	void shuffleDeck_test() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();

		ArrayList<Card> Deck1 = test.deck;
		test.shuffleDeck();
		int shuffled=0;

		for(int i=0;i<52;i++){
			if(Deck1.get(i).value != test.deck.get(0).value){
				shuffled++;
			}
		}

		assertNotEquals(0,shuffled,"Didn't shuffle the deck it is the same");

	}

	@Test
	void shuffleDeck_test1() {
		BaccaratDealer test1 = new BaccaratDealer();
		test1.generateDeck();

		ArrayList<Card> Deck1 = test1.deck;
		test1.shuffleDeck();
		test1.shuffleDeck();
		int shuffled=0;

		for(int i=0;i<52;i++){
			if(Deck1.get(i).value != test1.deck.get(0).value){
				shuffled++;
			}
		}

		assertNotEquals(0,shuffled,"Didn't shuffle the deck it is the same");

	}

	@Test
	void deck_size() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();

		assertEquals(52,test.deckSize(),"Incorrect deck size");

		test.dealHand();

		assertEquals(50,test.deckSize(),"Incorrect deck size");

	}

	@Test
	void deck_size1() {
		BaccaratDealer test = new BaccaratDealer();
		test.generateDeck();
		test.dealHand();
		test.drawOne();
		test.dealHand();

		assertEquals(47,test.deckSize(),"Incorrect deck size");

		test.shuffleDeck();

		assertEquals(52,test.deckSize(),"Incorrect deck size");
	}


}
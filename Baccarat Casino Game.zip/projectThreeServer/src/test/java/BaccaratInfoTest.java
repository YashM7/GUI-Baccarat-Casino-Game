import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class BaccaratInfoTest {

    @Test
    void BaccaratInfoConstructorTest(){
        BaccaratInfo b1 = new BaccaratInfo();

        assertEquals(0,b1.client_port,"Constructor is not working.");
        assertEquals(b1.playerValue ,0,"Constructor is not working.");
        assertEquals(b1.playerValue1 , 0,"Constructor is not working.");
        assertEquals(b1.bankerValue , 0,"Constructor is not working.");
        assertEquals(b1.bankerValue1 , 0,"Constructor is not working.");
        assertEquals(b1.total_winning, 0,"Constructor is not working.");
        assertEquals(0,b1.playerHand.size(),"Constructor is not working.");
        assertEquals(0,b1.bankerHand.size(),"Constructor is not working.");

    }

    @Test
    void setClient_addressTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClient_address("127.0.0.1");

        assertEquals("127.0.0.1",b1.client_address," set Client adress is not working");

    }
    @Test
    void setClient_addressTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClient_address("127.0.0.2");

        assertEquals("127.0.0.2",b1.client_address," set Client adress is not working");

    }

    @Test
    void getClient_addressTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClient_address("127.0.0.1");

        assertEquals("127.0.0.1",b1.getClient_address()," getClient_address is not working");

    }

    @Test
    void getClient_addressTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClient_address("127.0.0.2");

        assertEquals("127.0.0.2",b1.getClient_address()," getClient_address is not working");

    }

    @Test
    void setClientPort(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClientPort(5555);

        assertEquals(5555,b1.client_port," setClientPort is not working");

    }

    @Test
    void setClientPort1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClientPort(55656);

        assertEquals(55656,b1.client_port," setClientPort is not working");

    }

    @Test
    void getClientPort(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClientPort(5555);

        assertEquals(5555,b1.getClientPort()," getClientPort is not working");

    }

    @Test
    void getClientPort1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setClientPort(55656);

        assertEquals(55656,b1.getClientPort()," getClientPortis not working");

    }

    @Test
    void setCurrent_Bet(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setCurrent_Bet(1000);

        assertEquals(1000,b1.current_bet," setCurrent_Bet is not working");

    }

    @Test
    void setCurrent_Bet1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setCurrent_Bet(2000);

        assertEquals(2000,b1.current_bet," setCurrent_Betis not working");

    }

    @Test
    void getCurrent_Bet(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setCurrent_Bet(1000);

        assertEquals(1000,b1.getCurrent_Bet(),"getCurrent_Bet is not working");

    }

    @Test
    void getCurrent_Bet1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setCurrent_Bet(2000);

        assertEquals(2000,b1.getCurrent_Bet()," getCurrent_Bet is not working");

    }

    @Test
    void setTotalWinningTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setTotalWinning(1000);

        assertEquals(1000,b1.total_winning," setTotalWinningTest is not working");

    }

    @Test
    void setTotalWinningTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setTotalWinning(900);
        b1.setTotalWinning(-2000);

        assertEquals(-1100,b1.total_winning," setTotalWinningTest is not working");

    }

    @Test
    void getTotalWinningTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setTotalWinning(1000);

        assertEquals(1000,b1.getTotalWinning()," getTotalWinning is not working");

    }

    @Test
    void getTotalWinningTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setTotalWinning(900);
        b1.setTotalWinning(-2000);

        assertEquals(-1100,b1.getTotalWinning()," getTotalWinningis not working");

    }

    @Test
    void setBetOnTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setBetOn("player");

        assertEquals("player",b1.bet_on," setBetOn is not working");

    }

    @Test
    void setBetOn1Test(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setBetOn("Banker");


        assertEquals("Banker",b1.bet_on," setBetOn is not working");

        b1.setBetOn("Tie");

        assertEquals("Tie",b1.bet_on," setBetOn is not working");

    }

    @Test
    void getBetOnTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setBetOn("player");

        assertEquals("player",b1.bet_on," setBetOn is not working");

    }

    @Test
    void getBetOn1Test(){
        BaccaratInfo b1 = new BaccaratInfo();
        b1.setBetOn("Banker");


        assertEquals("Banker",b1.getBetOn()," setBetOn is not working");

        b1.setBetOn("Tie");

        assertEquals("Tie",b1.getBetOn()," setBetOn is not working");

    }

    @Test
    void setPlayerHandTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",10);
        Card c2= new Card("Heart",9);
        Card c3= new Card("Club",8);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setPlayerHand(C1);

        assertEquals(C1.size(),b1.playerHand.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),b1.playerHand.toArray(),"setPlayerHand is not working");


    }

    @Test
    void setPlayerHandTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",13);
        Card c2= new Card("Heart",10);
        Card c3= new Card("Club",6);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setPlayerHand(C1);

        assertEquals(C1.size(),b1.playerHand.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),b1.playerHand.toArray(),"setPlayerHand is not working");


    }

    @Test
    void getPlayerHandTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",10);
        Card c2= new Card("Heart",9);
        Card c3= new Card("Club",8);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setPlayerHand(C1);

        ArrayList<Card> C2 = b1.getPlayerHand();



        assertEquals(C1.size(),C2.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),C2.toArray(),"setPlayerHand is not working");


    }

    @Test
    void getPlayerHandTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",13);
        Card c2= new Card("Heart",10);
        Card c3= new Card("Club",6);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setPlayerHand(C1);
        ArrayList<Card> C2 = b1.getPlayerHand();

        assertEquals(C1.size(),C2.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),C2.toArray(),"setPlayerHand is not working");


    }
    @Test
    void setBankerHandTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",13);
        Card c2= new Card("Heart",10);
        Card c3= new Card("Club",6);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setBankerHand(C1);

        assertEquals(C1.size(),b1.bankerHand.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),b1.bankerHand.toArray(),"setPlayerHand is not working");


    }

    @Test
    void setBankerHandTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",13);
        Card c2= new Card("Heart",10);
        Card c3= new Card("Club",6);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setBankerHand(C1);

        assertEquals(C1.size(),b1.bankerHand.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),b1.bankerHand.toArray(),"setPlayerHand is not working");


    }

    @Test
    void getBankerHandTest(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",10);
        Card c2= new Card("Heart",9);
        Card c3= new Card("Club",8);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setBankerHand(C1);

        ArrayList<Card> C2 = b1.getBankerHand();



        assertEquals(C1.size(),C2.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),C2.toArray(),"setPlayerHand is not working");


    }

    @Test
    void getBankerHandTest1(){
        BaccaratInfo b1 = new BaccaratInfo();
        Card c1= new Card("Heart",13);
        Card c2= new Card("Heart",10);
        Card c3= new Card("Club",6);

        ArrayList<Card> C1= new ArrayList<>();
        C1.add(c1);
        C1.add(c2);
        C1.add(c3);

        b1.setBankerHand(C1);
        ArrayList<Card> C2 = b1.getBankerHand();

        assertEquals(C1.size(),C2.size(),"setPlayerHand is not working");
        assertArrayEquals(C1.toArray(),C2.toArray(),"setPlayerHand is not working");


    }





}
